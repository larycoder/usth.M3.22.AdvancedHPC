#pragma warning(disable : 4996)
#pragma once
#define _SILENCE_CXX17_ITERATOR_BASE_CLASS_DEPRECATION_WARNING
#define _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS

#include <OPP/OPP_tools.h>
#include <OPP/OPP_barrier.h>
#include <OPP/OPP_iterator.h>

