#pragma once

// we define Our Parallel Pattern namespace -> OPP
namespace OPP 
{
    // need to be defined once, somewhere
    extern unsigned nbThreads;
}